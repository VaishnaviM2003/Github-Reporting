const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');

test.describe('Login', () => {
  test('should fail with invalid credentials', async ({ page }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.login('wrong-user', 'wrong-pass');
    await expect(login.errorMsg).toBeVisible();
  });

  test('should succeed with valid credentials (demo)', async ({ page }) => {
    const login = new LoginPage(page);
    await login.goto();
    await login.login(process.env.USERNAME || 'demo', process.env.PASSWORD || 'demo');
    await expect(page).toHaveURL(/dashboard|home/i);
  });
});
