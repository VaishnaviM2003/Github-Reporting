class LoginPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;
    this.username = page.getByLabel(/username/i);
    this.password = page.getByLabel(/password/i);
    this.submit   = page.getByRole('button', { name: /log ?in/i });
    this.errorMsg = page.locator('[data-test="login-error"]');
  }

  async goto() {
    await this.page.goto('/');
  }

  async login(user, pass) {
    await this.username.fill(user);
    await this.password.fill(pass);
    await this.submit.click();
  }
}

module.exports = { LoginPage };
