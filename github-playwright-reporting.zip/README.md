# Playwright + GitHub Reporting

End-to-end UI testing project powered by [Playwright](https://playwright.dev/).  
This setup includes:
- Cross-browser testing (Chromium, Firefox, WebKit)
- Page Object Model (POM) for maintainable tests
- Multiple reporters: HTML, JUnit, Allure
- Artifacts uploaded in GitHub Actions
- Reusable GitHub Actions workflow

## Project Structure
```
.github/
 └─ workflows/
    └─ playwright.yml
tests/
 ├─ specs/
 │   └─ login.spec.js
 └─ pages/
     └─ LoginPage.js
utils/
 └─ test-helpers.js
.env.example
.gitignore
package.json
playwright.config.js
README.md
```

## Getting Started
```bash
git clone https://github.com/your-org/github-playwright-reporting.git
cd github-playwright-reporting
npm ci
npm run install:pw
cp .env.example .env
# edit .env with your APP_BASE_URL, USERNAME, PASSWORD
```

## Running Tests
```bash
npm test            # headless
npm run test:headed # visible browsers
npm run test:ui     # interactive UI
```

## Reports
```bash
npm run report:open   # Playwright HTML
npm run allure:gen    # Allure generate
npm run allure:open   # Allure open
```

## CI/CD (GitHub Actions)
- Push to `main` or open a PR → workflow runs automatically
- Artifacts: `playwright-report/`, `test-results/`, `allure-report/`

## Useful Scripts
| Command               | Description                         |
|-----------------------|-------------------------------------|
| npm test              | Run tests                           |
| npm run test:headed   | Browser headed mode                 |
| npm run test:ui       | Playwright Test UI                  |
| npm run report:open   | Open HTML report                    |
| npm run allure:gen    | Generate Allure report              |
| npm run allure:open   | Serve Allure report locally         |
| npm run ci            | CI run with all reporters           |

## Troubleshooting
- Run `npm run install:pw` if browsers missing
- Verify selectors and `.env` values if tests fail
- Artifacts uploaded with `if: always()` even on failures
